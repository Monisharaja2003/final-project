package com.aim.aim_backend.web;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aim.aim_backend.model.UserPolicy;
import com.aim.aim_backend.service.UserPolicyService;

@RestController
@RequestMapping("/api/user-policies")
public class UserPolicyController {

    private final UserPolicyService userPolicyService;

    public UserPolicyController(UserPolicyService userPolicyService) {
        this.userPolicyService = userPolicyService;
    }

    @PostMapping
    public ResponseEntity<?> apply(@RequestBody UserPolicy req, org.springframework.security.core.Authentication auth) {
        try {
            String userEmail = auth != null ? auth.getName() : "user@example.com";
            UserPolicy up = userPolicyService.applyPolicy(userEmail, req);
            return ResponseEntity.ok(up);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> myPolicies(org.springframework.security.core.Authentication auth) {
        try {
            String userEmail = auth != null ? auth.getName() : "user@example.com";
            return ResponseEntity.ok(userPolicyService.getUserPolicies(userEmail));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
    

}


