package com.aim.aim_backend.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.aim.aim_backend.model.Policy;
import com.aim.aim_backend.repository.PolicyRepository;
import com.aim.aim_backend.web.PolicyController.PolicyRequest;

@Service
public class PolicyService {

    private final PolicyRepository policyRepository;

    public PolicyService(PolicyRepository policyRepository) {
        this.policyRepository = policyRepository;
    }

    public Policy createPolicy(PolicyRequest request) {
        Policy policy = new Policy();
        policy.setPolicyName(request.getPolicyName());
        policy.setVehicleType(request.getVehicleType());
        policy.setCoverageType(request.getCoverageType());
        policy.setPremiumAmount(new BigDecimal(request.getPremiumAmount()));
        policy.setCoverageAmount(new BigDecimal(request.getCoverageAmount()));
        policy.setDuration(request.getDuration());
        policy.setDescription(request.getDescription());
        policy.setBenefits(request.getBenefits());
        policy.setTerms(request.getTerms());
        policy.setCreatedByAdmin(request.getCreatedByAdmin());
        
        return policyRepository.save(policy);
    }

    public List<Policy> getAllPolicies() {
        return policyRepository.findAll();
    }
    

}