// Authentication context for managing user login state and protected routes
import React, { createContext, useContext, useEffect, useState } from "react";
import client from "../api/client";
import { Navigate } from "react-router-dom";

const AuthContext = createContext(null);

// Provides authentication state to entire app
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is already logged in
  const load = async () => {
    try {
      const res = await client.get("/api/auth/me");
      setUser(res.data);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  // Runs load() once when the app starts.
  useEffect(() => {
    load();
  }, []);

  // Logout user and redirect to home
  const logout = async () => {
    try {
      await client.post("/api/auth/logout");
    } catch (error) {
    } finally {
      setUser(null);
      window.location.replace("/");
    }
  };

  const value = { user, setUser, reload: load, logout };
  
  return (
    <AuthContext.Provider value={value}>
      {loading ? null : children}
    </AuthContext.Provider>
  );
};

// Hook to access auth context
export const useAuth = () => useContext(AuthContext);

// Protects routes based on user role (USER/ADMIN)
export const ProtectedRoute = ({ children, role }) => {
  const { user } = useAuth();
  
  if (!user) return <Navigate to="/login" replace />;
  return children;
};
