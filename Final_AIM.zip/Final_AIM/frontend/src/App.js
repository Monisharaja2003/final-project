/**
 * Main App Component - Entry point for the Auto Shield Insurance Management System
 * 
 * This component sets up the main routing structure for the application:
 * - Public routes: Home, Login, Signup (accessible to all users)
 * - Protected routes: User Dashboard, Admin Dashboard (role-based access)
 * 
 * Key Features:
 * - Role-based routing with authentication checks
 * - Layout wrapper for public pages
 * - Separate dashboard layouts for users and admins
 * - Fallback route redirects to home page
 */

import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import UserDashboard from "./pages/user/UserDashboard";
import AdminDashboard from "./pages/admin/AdminDashboard";
import { ProtectedRoute } from "./context/AuthContext";

function App() {
  return (
    <Routes>
      {/* Public Routes - Accessible to all users */}
      <Route element={<Layout />}>
        <Route path="/" element={<HomePage />} />           {/* Landing page with company info */}
        <Route path="/login" element={<LoginPage />} />     {/* User/Admin login */}
        <Route path="/signup" element={<SignupPage />} />   {/* User/Admin registration */}
      </Route>
      
      {/* Protected User Routes - Only accessible to authenticated users with USER role */}
      <Route
        path="/user/*"
        element={
          <ProtectedRoute role="USER">
            <UserDashboard />  {/* User dashboard with policy management, claims, queries */}
          </ProtectedRoute>
        }
      />
      
      {/* Protected Admin Routes - Only accessible to authenticated users with ADMIN role */}
      <Route
        path="/admin/*"
        element={
          <ProtectedRoute role="ADMIN">
            <AdminDashboard />  {/* Admin dashboard with policy creation, claim management */}
          </ProtectedRoute>
        }
      />
      
      {/* Fallback Route - Redirects any unknown routes to home page */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
