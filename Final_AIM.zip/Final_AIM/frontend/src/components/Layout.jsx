import {
  Link as RouterLink,
  useNavigate,
  useLocation,
  Outlet,
} from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./Layout.css";

const Layout = () => {
  const { user, logout } = useAuth();//get current user&logout function from AuthContext.
  const navigate = useNavigate();//navigate programmatically to different routes.Example: navigate("/login") redirects to login page.
  const location = useLocation();//access to the current URL path&other location info.Example: location.pathname might return "/about".


  const handleLogout = () => {
    logout();
  };

  const scrollToSection = (sectionId) => {//scrolls smoothly to a section of the page identified by sectionId.
    if (location.pathname !== "/") {
      navigate("/");
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  const navItems = [
    { label: "Home", id: "home" },
    { label: "About Us", id: "about" },
    { label: "Services", id: "services" },
    { label: "Contact", id: "contact" },
  ];

  return (
    <div className="layout-root">
      <header className="site-header">
        <div className="header-bar">
          <div className="brand" onClick={() => navigate("/")}>
            Auto Shield
          </div>
          <nav className="nav">
            {navItems.map((item) => (
              <a key={item.id} onClick={() => scrollToSection(item.id)}>
                {item.label}
              </a>
            ))}
            {user ? (
              <a onClick={handleLogout}>Logout</a>
            ) : (
              <RouterLink to="/login">Login</RouterLink>
            )}
          </nav>
        </div>
      </header>

      <main className="site-main">
        <Outlet />
      </main>

      <footer className="site-footer">
        <div className="container">
          <div className="footer-grid">
            <div>
              <div className="footer-brand">Auto Shield</div>
              <div className="footer-muted mb-3">
                Your trusted partner for comprehensive auto insurance solutions.
                Protecting your journey with reliable coverage and exceptional
                service.
              </div>
            </div>
            <div>
              <div className="h4 mb-2">Quick Links</div>
              <div className="footer-links">
                {navItems.map((item) => (
                  <a
                    key={item.id}
                    className="footer-link"
                    onClick={() => scrollToSection(item.id)}
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>
            <div>
              <div className="h4 mb-2">Contact Info</div>
              <div className="footer-muted">
                📍 Auto Shield Insurance, 123 Business Park, Anna Salai, Chennai, Tamil Nadu 600002
              </div>
              <div className="footer-muted">📞 +91 98765 43210</div>
              <div className="footer-muted">📧 support@autoshield.example</div>
            </div>
          </div>
          <div className="footer-bottom">
            <div className="footer-muted">
              © {new Date().getFullYear()} Auto Shield. All rights
              reserved.
            </div>
            <div style={{ display: "flex", gap: 16 }}>
              <a className="policy">Privacy Policy</a>
              <a className="policy">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
