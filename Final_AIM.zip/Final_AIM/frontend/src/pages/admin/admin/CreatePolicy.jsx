import React, { useState } from "react";
import client from "../../../api/client";
import "./CreatePolicy.css";

const CreatePolicy = () => {
  const [form, setForm] = useState({
    policyName: "",
    vehicleType: "Two-Wheeler",
    coverageType: "Comprehensive",
    premiumAmount: "",
    coverageAmount: "",
    duration: 12,
    description: "",
    isActive: true
  });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});



  const validateForm = () => {
    const errors = {};

    if (!form.policyName.trim()) {
      errors.policyName = "Policy name is required";
    }

    if (!form.premiumAmount || form.premiumAmount < 1000) {
      errors.premiumAmount = "Premium amount must be at least ₹1,000";
    }

    if (!form.coverageAmount || form.coverageAmount < 100000) {
      errors.coverageAmount = "Coverage amount must be at least ₹1,00,000";
    }

    if (!form.description.trim()) {
      errors.description = "Policy description is required";
    }



    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const submit = async (e) => {
    e.preventDefault();
    setValidationErrors({});

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      const policyData = {
        policyName: form.policyName,
        vehicleType: form.vehicleType,
        coverageType: form.coverageType,
        premiumAmount: form.premiumAmount.toString(),
        coverageAmount: form.coverageAmount.toString(),
        duration: parseInt(form.duration),
        description: form.description.trim(),
        benefits: `• Coverage protection\n• Claim settlement`,
        terms: `Policy valid for ${form.duration} months. Premium payment required.`,
        isActive: form.isActive,
        createdByAdmin: 1
      };

      await client.post("/api/policies", policyData);
      setMessage("Policy created successfully!");

      // Reset form
      setForm({
        policyName: "",
        vehicleType: "Two-Wheeler",
        coverageType: "Comprehensive",
        premiumAmount: "",
        coverageAmount: "",
        duration: 12,
        description: "",
        isActive: true
      });
    } catch (err) {
      setMessage(err.response?.data?.message || "Failed to create policy. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="create-policy-container">
      <h2 className="create-policy-title">Create Insurance Policy</h2>
      
      {message && (
        <div className={`create-policy-alert ${message.includes('successfully') ? 'success' : 'error'}`}>
          {message}
        </div>
      )}
      
      <p className="create-policy-description">
        Create new insurance policies that users can view and apply for. Fill in all the required details to make the policy available.
      </p>

      <form onSubmit={submit} className="create-policy-form">
        <div className="create-policy-grid">
          {/* Policy Name */}
          <div className="create-policy-field full-width">
            <label className="create-policy-label">Policy Name *</label>
            <input
              className={`create-policy-input ${validationErrors.policyName ? 'error' : ''}`}
              value={form.policyName}
              onChange={(e) => setForm({ ...form, policyName: e.target.value })}
              placeholder="e.g., Premium Bike Insurance, Family Car Protection"
              required
            />
            {validationErrors.policyName && (
              <span className="create-policy-error-text">{validationErrors.policyName}</span>
            )}
          </div>

          {/* Vehicle Type */}
          <div className="create-policy-field">
            <label className="create-policy-label">Vehicle Type *</label>
            <select
              className="create-policy-select"
              value={form.vehicleType}
              onChange={(e) => setForm({ ...form, vehicleType: e.target.value })}
            >
              <option value="Two-Wheeler">Two-Wheeler</option>
              <option value="Four-Wheeler">Four-Wheeler</option>
            </select>
          </div>

          {/* Coverage Type */}
          <div className="create-policy-field">
            <label className="create-policy-label">Coverage Type *</label>
            <select
              className="create-policy-select"
              value={form.coverageType}
              onChange={(e) => setForm({ ...form, coverageType: e.target.value })}
            >
              <option value="Comprehensive">Comprehensive</option>
              <option value="Third-Party">Third-Party</option>
              <option value="Zero Depreciation">Zero Depreciation</option>
              <option value="Personal Accident">Personal Accident</option>
            </select>
          </div>

          {/* Premium Amount */}
          <div className="create-policy-field">
            <label className="create-policy-label">Premium Amount (₹) *</label>
            <input
              className={`create-policy-input ${validationErrors.premiumAmount ? 'error' : ''}`}
              type="number"
              value={form.premiumAmount}
              onChange={(e) => setForm({ ...form, premiumAmount: e.target.value })}
              min="1000"
              step="100"
              placeholder="5000"
              required
            />
            {validationErrors.premiumAmount ? (
              <span className="create-policy-error-text">{validationErrors.premiumAmount}</span>
            ) : (
              <span className="create-policy-helper-text">Minimum ₹1,000</span>
            )}
          </div>

          {/* Coverage Amount - Manual Input */}
          <div className="create-policy-field">
            <label className="create-policy-label">Coverage Amount (₹) *</label>
            <input
              className={`create-policy-input ${validationErrors.coverageAmount ? 'error' : ''}`}
              type="number"
              value={form.coverageAmount}
              onChange={(e) => setForm({ ...form, coverageAmount: e.target.value })}
              min="100000"
              step="10000"
              placeholder="500000"
              required
            />
            {validationErrors.coverageAmount ? (
              <span className="create-policy-error-text">{validationErrors.coverageAmount}</span>
            ) : (
              <span className="create-policy-helper-text">Minimum ₹1,00,000</span>
            )}
          </div>

          {/* Duration */}
          <div className="create-policy-field">
            <label className="create-policy-label">Policy Duration (Months) *</label>
            <select
              className="create-policy-select"
              value={form.duration}
              onChange={(e) => setForm({ ...form, duration: e.target.value })}
            >
              <option value={12}>12 months</option>
              <option value={24}>24 months</option>
              <option value={36}>36 months</option>
            </select>
          </div>
        </div>

        <div className="create-policy-divider"></div>
        <h3 className="create-policy-section-title">Policy Details</h3>

        <div className="create-policy-grid">
          {/* Description */}
          <div className="create-policy-field full-width">
            <label className="create-policy-label">Policy Description *</label>
            <textarea
              className={`create-policy-textarea ${validationErrors.description ? 'error' : ''}`}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Describe what this policy covers and its key features..."
              rows={4}
              required
            />
            {validationErrors.description && (
              <span className="create-policy-error-text">{validationErrors.description}</span>
            )}
          </div>
        </div>

        <button
          type="submit"
          className="create-policy-button"
          disabled={loading}
        >
          {loading ? (
            <>
              <div className="create-policy-loading"></div>
              Creating Policy...
            </>
          ) : (
            "Create Policy"
          )}
        </button>
      </form>
    </div>
  );
};

export default CreatePolicy;
