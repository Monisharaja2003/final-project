import React, { useEffect, useState } from "react";
import client from "../../../api/client";
import "./ManageClaims.css";

const ManageClaims = () => {
  const [rows, setRows] = useState([]);

  const [selectedClaim, setSelectedClaim] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  
  const load = async () => {
    try {
      const claimsRes = await client.get("/api/claims/all");
      setRows(claimsRes.data || []);
    } catch (err) {
      setRows([]);
    }
  };
  
  useEffect(() => {
    load();
  }, []);

  const setStatus = async (id, status) => {
    await client.put(`/api/claims/${id}/status`, null, { params: { status } });
    await load();
    setShowDialog(false);
  };

  const viewClaim = (claim) => {
    setSelectedClaim(claim);
    setShowDialog(true);
  };

  return (
    <div className="manage-root">
      <h3 className="h3 manage-title">Manage Claims</h3>
      <div className="card">
        <div className="card-body">
          <table className="manage-table">
            <thead>
              <tr>
                <th>Claim #</th>
                <th>User</th>
                <th>Policy ID</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const details = (() => { try { return JSON.parse(r.details || "{}"); } catch { return {}; } })();
                return (
                  <tr key={r.id}>
                    <td>#{r.id}</td>
                    <td>User {r.userId || 'N/A'}</td>
                    <td>{r.policyId || 'N/A'}</td>
                    <td>{r.claimType || details.claimType || 'N/A'}</td>
                    <td>{r.requestedAmount ? `₹${Number(r.requestedAmount).toLocaleString()}` : details.requestedAmount ? `₹${Number(details.requestedAmount).toLocaleString()}` : 'N/A'}</td>
                    <td>
                      <span className={`status-badge status-${r.status?.toLowerCase()}`}>
                        {r.status || 'PENDING'}
                      </span>
                    </td>
                  <td>
                    <div className="manage-actions">
                      <button
                        className="btn btn-primary"
                        onClick={() => viewClaim(r)}
                        style={{marginRight: '8px'}}
                      >
                        View
                      </button>
                      {r.status === "PENDING" && (
                        <>
                          <button
                            className="btn btn-approve"
                            onClick={() => setStatus(r.id, "APPROVED")}
                          >
                            Approve
                          </button>
                          <button
                            className="btn btn-reject"
                            onClick={() => setStatus(r.id, "REJECTED")}
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      
      {showDialog && selectedClaim && (
        <div className="policy-dialog-overlay" onClick={() => setShowDialog(false)}>
          <div className="claim-dialog" onClick={(e)=>e.stopPropagation()}>
            <div className="claim-dialog-header">
              <h3 className="claim-dialog-title">Claim Details #{selectedClaim.id}</h3>
              <button className="claim-dialog-close" onClick={()=>setShowDialog(false)}>×</button>
            </div>
            <div className="claim-dialog-body">
              {(() => { 
                let d={}; 
                try{ d = JSON.parse(selectedClaim.details||"{}"); } catch(e){} 
                return (
                  <div className="claim-details-container">
                    <div className="claim-details-grid">
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">User</span>
                        <span className="claim-detail-value">User {selectedClaim.userId || 'N/A'}</span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Status</span>
                        <span className={`claim-detail-value status-${selectedClaim.status?.toLowerCase()}`}>
                          {selectedClaim.status || "PENDING"}
                        </span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Policy ID</span>
                        <span className="claim-detail-value">{selectedClaim.policyId || "N/A"}</span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Claim Number</span>
                        <span className="claim-detail-value">{selectedClaim.claimNumber || d.claimNumber || "N/A"}</span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Claim Type</span>
                        <span className="claim-detail-value">{selectedClaim.claimType || d.claimType || "N/A"}</span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Contact Number</span>
                        <span className="claim-detail-value">{d.contactNumber || "N/A"}</span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Incident Date</span>
                        <span className="claim-detail-value">
                          {selectedClaim.incidentDate ? new Date(selectedClaim.incidentDate).toLocaleDateString() : d.incidentDate ? new Date(d.incidentDate).toLocaleDateString() : "N/A"}
                        </span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Requested Amount</span>
                        <span className="claim-detail-value amount">
                          {(selectedClaim.requestedAmount || d.requestedAmount) ? `₹${Number(selectedClaim.requestedAmount || d.requestedAmount).toLocaleString()}` : "N/A"}
                        </span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Approved Amount</span>
                        <span className="claim-detail-value amount">
                          {(selectedClaim.approvedAmount || d.approvedAmount) ? `₹${Number(selectedClaim.approvedAmount || d.approvedAmount).toLocaleString()}` : "N/A"}
                        </span>
                      </div>
                      <div className="claim-detail-item">
                        <span className="claim-detail-label">Estimated Amount</span>
                        <span className="claim-detail-value amount">
                          {(selectedClaim.estimatedAmount || d.estimatedAmount) ? `₹${Number(selectedClaim.estimatedAmount || d.estimatedAmount).toLocaleString()}` : "N/A"}
                        </span>
                      </div>
                      <div className="claim-detail-item full-width">
                        <span className="claim-detail-label">Address</span>
                        <span className="claim-detail-value">{d.address || "N/A"}</span>
                      </div>
                      <div className="claim-detail-item full-width">
                        <span className="claim-detail-label">Description</span>
                        <span className="claim-detail-value">{selectedClaim.description || d.description || "N/A"}</span>
                      </div>
                    </div>
                    
                    {(selectedClaim.imageUrl || d.imageUrl) && (
                      <div className="claim-image-section">
                        <h4 className="claim-image-title">Incident Photo</h4>
                        <div className="claim-image-container">
                          <img 
                            src={selectedClaim.imageUrl || d.imageUrl} 
                            alt="Claim evidence" 
                            className="claim-image"
                            onClick={() => {
                              setSelectedImage(selectedClaim.imageUrl || d.imageUrl);
                              setShowImageModal(true);
                            }}
                          />
                          <p className="claim-image-hint">Click to view full size</p>
                        </div>
                      </div>
                    )}
                    
                    {selectedClaim.status === "PENDING" && (
                      <div className="claim-actions">
                        <button
                          className="btn btn-approve"
                          onClick={() => setStatus(selectedClaim.id, "APPROVED")}
                        >
                          Approve Claim
                        </button>
                        <button
                          className="btn btn-reject"
                          onClick={() => setStatus(selectedClaim.id, "REJECTED")}
                        >
                          Reject Claim
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}
      
      {showImageModal && selectedImage && (
        <div className="image-modal-overlay" onClick={() => setShowImageModal(false)}>
          <div className="image-modal" onClick={(e) => e.stopPropagation()}>
            <div className="image-modal-header">
              <h3>Incident Photo</h3>
              <button className="image-modal-close" onClick={() => setShowImageModal(false)}>×</button>
            </div>
            <div className="image-modal-body">
              <img src={selectedImage} alt="Claim evidence" className="image-modal-img" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageClaims;
