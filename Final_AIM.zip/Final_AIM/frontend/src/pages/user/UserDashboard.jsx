import React, { useState } from "react";
import { Routes, Route, Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import AppliedPolicies from "./user/AppliedPolicies";
import ApplyClaim from "./user/ApplyClaim";
import UserQueries from "./user/UserQueries";
import TrackClaims from "./user/TrackClaims";
import AvailablePolicies from "./user/AvailablePolicies";
import UserProfile from "./user/UserProfile";
import "./UserDashboard.css";

const UserDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const menuItems = [
    { path: "/user/available-policies", label: "Available Policies", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/clipboard-document-list.svg" },
    { path: "/user/applied-policies", label: "Applied Policies", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/document-check.svg" },
    { path: "/user/apply-claim", label: "Apply Claims", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/document-plus.svg" },
    { path: "/user/track-claims", label: "Track Claims", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/magnifying-glass.svg" },
    { path: "/user/queries", label: "Queries", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/chat-bubble-left-right.svg" },
    { path: "/user/profile", label: "Profile", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/user.svg" },
  ];

  return (
    <div className="user-dashboard">
      <header className="user-appbar">
        <div className="user-toolbar">
          <button className="user-collapse-btn" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
            {sidebarCollapsed ? '→' : '←'}
          </button>
          <div className="user-title-container">
            <h1 className="user-title">User Dashboard</h1>
          </div>
          <button className="user-logout-btn" onClick={logout}>
            Logout
          </button>
        </div>
      </header>

      <nav className={`user-drawer ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <ul className="user-drawer-list">
          {menuItems.map((item) => (
            <li key={item.path} className="user-drawer-item">
              <Link
                to={item.path}
                className={`user-drawer-link ${
                  location.pathname === item.path ? 'active' : ''
                }`}
                onClick={() => {
                  if (location.pathname === item.path) {
                    setSidebarCollapsed(!sidebarCollapsed);
                  }
                }}
              >
                <img src={item.icon} alt="" className="user-drawer-icon" />
                <span className="user-drawer-text">{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <main className={`user-main ${sidebarCollapsed ? 'expanded' : ''}`}>
        <Routes>
          <Route path="available-policies" element={<AvailablePolicies />} />
          {/* <Route path="apply-policy" element={<ApplyPolicy />} /> */}
          <Route path="applied-policies" element={<AppliedPolicies />} />
          <Route path="apply-claim" element={<ApplyClaim />} />
          <Route path="track-claims" element={<TrackClaims />} />
          <Route path="queries" element={<UserQueries />} />
          <Route path="profile" element={<UserProfile />} />
          <Route path="*" element={<AvailablePolicies />} />
        </Routes>
      </main>
    </div>
  );
};

export default UserDashboard;
