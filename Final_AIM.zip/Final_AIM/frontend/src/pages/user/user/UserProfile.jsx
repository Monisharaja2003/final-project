import React from "react";
import { useAuth } from "../../../context/AuthContext";

const UserProfile = () => {
  const { user } = useAuth();

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <div style={{
        background: 'var(--surface)',
        borderRadius: 'var(--border-radius-lg)',
        boxShadow: 'var(--shadow-md)',
        padding: '2rem',
        border: '1px solid var(--border)'
      }}>
        <div style={{ marginBottom: '1.5rem' }}>
          <h2 style={{
            fontSize: '1.5rem',
            fontWeight: '600',
            color: 'var(--primary)',
            margin: 0,
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            👤 User Profile
          </h2>
        </div>

        <div style={{ display: 'grid', gap: '1rem' }}>
          <div style={{
            padding: '1rem',
            background: 'var(--background)',
            borderRadius: 'var(--border-radius-md)',
            border: '1px solid var(--border)'
          }}>
            <label style={{
              fontWeight: '500',
              color: 'var(--text-primary)',
              fontSize: '0.875rem',
              display: 'block',
              marginBottom: '0.5rem'
            }}>
              Full Name
            </label>
            <div style={{
              fontSize: '1rem',
              color: 'var(--text-primary)',
              fontWeight: '500'
            }}>
              {user?.name || 'N/A'}
            </div>
          </div>

          <div style={{
            padding: '1rem',
            background: 'var(--background)',
            borderRadius: 'var(--border-radius-md)',
            border: '1px solid var(--border)'
          }}>
            <label style={{
              fontWeight: '500',
              color: 'var(--text-primary)',
              fontSize: '0.875rem',
              display: 'block',
              marginBottom: '0.5rem'
            }}>
              Email Address
            </label>
            <div style={{
              fontSize: '1rem',
              color: 'var(--text-primary)',
              fontWeight: '500'
            }}>
              {user?.email || 'N/A'}
            </div>
          </div>

          <div style={{
            padding: '1rem',
            background: 'var(--background)',
            borderRadius: 'var(--border-radius-md)',
            border: '1px solid var(--border)'
          }}>
            <label style={{
              fontWeight: '500',
              color: 'var(--text-primary)',
              fontSize: '0.875rem',
              display: 'block',
              marginBottom: '0.5rem'
            }}>
              Role
            </label>
            <div style={{
              fontSize: '1rem',
              color: 'var(--primary)',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              👤 {user?.role || 'N/A'}
            </div>
          </div>

          <div style={{
            padding: '1rem',
            background: 'var(--background)',
            borderRadius: 'var(--border-radius-md)',
            border: '1px solid var(--border)'
          }}>
            <label style={{
              fontWeight: '500',
              color: 'var(--text-primary)',
              fontSize: '0.875rem',
              display: 'block',
              marginBottom: '0.5rem'
            }}>
              User ID
            </label>
            <div style={{
              fontSize: '1rem',
              color: 'var(--text-secondary)',
              fontFamily: 'monospace'
            }}>
              #{user?.id || 'N/A'}
            </div>
          </div>


        </div>
      </div>
    </div>
  );
};

export default UserProfile;