package com.aim.aim_backend.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aim.aim_backend.model.Claim;
import com.aim.aim_backend.model.User;
import com.aim.aim_backend.repository.ClaimRepository;
import com.aim.aim_backend.repository.UserRepository;

@Service
public class ClaimService {

    private final ClaimRepository claimRepository;
    private final UserRepository userRepository;

    public ClaimService(ClaimRepository claimRepository, UserRepository userRepository) {
        this.claimRepository = claimRepository;
        this.userRepository = userRepository;
    }

    public List<Claim> getClaimsByUserId(Long userId) {
        if (userId != null) {
            return claimRepository.findByUserId(userId);
        }
        return claimRepository.findAll();
    }

    public List<Claim> getClaimsByUserEmail(String userEmail) {
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        return claimRepository.findByUserId(user.getId());
    }

    public Claim updateClaimStatus(Long id, String status) {
        Claim claim = claimRepository.findById(id).orElseThrow();
        claim.setStatus(status);
        return claimRepository.save(claim);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }

    public Claim submitClaimWithUserId(Claim claim) {
        if (claim.getUserId() == null) {
            throw new RuntimeException("User ID is required for claim submission");
        }
        if (claim.getPolicyId() == null) {
            throw new RuntimeException("Policy ID is required for claim submission");
        }
        if (claim.getClaimType() == null || claim.getClaimType().trim().isEmpty()) {
            throw new RuntimeException("Claim type is required for claim submission");
        }
        
        claim.setStatus("PENDING");
        claim.setPaymentStatus("RECEIVED");
        
        if (claim.getCreatedAt() == null) {
            claim.setCreatedAt(java.time.LocalDateTime.now());
        }
        
        if (claim.getClaimNumber() == null || claim.getClaimNumber().isEmpty()) {
            claim.setClaimNumber("CLM" + System.currentTimeMillis());
        }
        
        return claimRepository.save(claim);
    }
}