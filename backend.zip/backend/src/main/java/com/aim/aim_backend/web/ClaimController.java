package com.aim.aim_backend.web;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aim.aim_backend.model.Claim;
import com.aim.aim_backend.service.ClaimService;

@RestController
@RequestMapping("/api/claims")
@CrossOrigin(origins = "http://localhost:3000")
public class ClaimController {

    private final ClaimService claimService;

    public ClaimController(ClaimService claimService) {
        this.claimService = claimService;
    }

    @PostMapping
    public ResponseEntity<?> apply(@RequestBody Claim claim, Authentication auth) {
        if (auth == null) {
            return ResponseEntity.status(401).body("Authentication required");
        }
        try {
            Claim savedClaim = claimService.submitClaimWithUserId(claim);
            return ResponseEntity.ok(savedClaim);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(500).body("Internal server error");
        }
    }

    @GetMapping
    public ResponseEntity<List<Claim>> myClaims(@Nullable Authentication auth, @RequestParam(required = false) Long userId) {
        if (auth != null && auth.getName() != null && userId == null) {
            // For regular users, get their own claims
            return ResponseEntity.ok(claimService.getClaimsByUserEmail(auth.getName()));
        }
        return ResponseEntity.ok(claimService.getClaimsByUserId(userId));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Claim>> getAllClaims() {
        return ResponseEntity.ok(claimService.getAllClaims());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Claim> setStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(claimService.updateClaimStatus(id, status));
    }
    

}


