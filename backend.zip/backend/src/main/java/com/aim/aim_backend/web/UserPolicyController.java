package com.aim.aim_backend.web;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aim.aim_backend.model.UserPolicy;
import com.aim.aim_backend.service.UserPolicyService;

@RestController
@RequestMapping("/api/user-policies")
public class UserPolicyController {

    private final UserPolicyService userPolicyService;

    public UserPolicyController(UserPolicyService userPolicyService) {
        this.userPolicyService = userPolicyService;
    }

    @PostMapping
    public ResponseEntity<?> apply(@RequestBody UserPolicy req, org.springframework.security.core.Authentication auth) {
        if (auth == null) {
            return ResponseEntity.status(401).body("Authentication required");
        }
        try {
            UserPolicy up = userPolicyService.applyPolicy(auth.getName(), req);
            return ResponseEntity.ok(up);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(500).body("Internal server error");
        }
    }

    @GetMapping
    public ResponseEntity<?> myPolicies(org.springframework.security.core.Authentication auth) {
        if (auth == null) {
            return ResponseEntity.status(401).body("Authentication required");
        }
        try {
            return ResponseEntity.ok(userPolicyService.getUserPolicies(auth.getName()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(500).body("Internal server error");
        }
    }
    

}


